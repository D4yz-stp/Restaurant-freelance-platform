<?php
// Iniciar sessão
session_start();

// Verificar se o usuário está logado
if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_role'])) {
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Usuário não autenticado']);
    exit();
}

// Verificar se o conversation_id foi fornecido
if (!isset($_GET['conversation_id'])) {
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Parâmetros insuficientes']);
    exit();
}

$conversation_id = (int)$_GET['conversation_id'];
$user_id = $_SESSION['user_id'];
$user_role = $_SESSION['user_role'];

$databasePath = '../../database/TesteOlga.db';
if (!file_exists($databasePath)) {
    die("O arquivo de banco de dados não existe no caminho especificado: $databasePath");
}

if (!is_readable($databasePath)) {
    die("O arquivo de banco de dados não é legível. Verifique as permissões.");
}


// Conexão com o banco de dados
try {
    $db = new SQLite3($databasePath);
    $db->busyTimeout(5000);
    $db->exec('PRAGMA foreign_keys = ON;');

    $user_id = $_SESSION['user_id'];
    $user_role = $_SESSION['user_role'];

    // Obter perfil do usuário baseado no papel
    $profile_id = null;
    $conversations = [];

    // Continue com o resto do seu código...

} catch (Exception $e) {
    die("Erro ao conectar ao banco de dados: " . $e->getMessage());
}


// Verificar se o usuário tem acesso à conversa
$valid_conversation = false;
$profile_id = null;
$other_user_id = null;

if ($user_role === 'freelancer') {
    $stmt = $db->prepare("SELECT f.profile_id FROM FreelancerProfiles f WHERE f.user_id = :user_id");
    $stmt->bindValue(':user_id', $user_id, SQLITE3_INTEGER);
    $result = $stmt->execute();
    
    if ($row = $result->fetchArray(SQLITE3_ASSOC)) {
        $profile_id = $row['profile_id'];
        
        $stmt = $db->prepare("SELECT c.conversation_id, r.user_id as other_user_id 
                            FROM Conversations c
                            JOIN RestaurantProfiles r ON c.restaurant_id = r.restaurant_id
                            WHERE c.conversation_id = :conversation_id AND c.freelancer_id = :profile_id");
        $stmt->bindValue(':conversation_id', $conversation_id, SQLITE3_INTEGER);
        $stmt->bindValue(':profile_id', $profile_id, SQLITE3_INTEGER);
        $result = $stmt->execute();
        
        if ($row = $result->fetchArray(SQLITE3_ASSOC)) {
            $valid_conversation = true;
            $other_user_id = $row['other_user_id'];
        }
    }
} else if ($user_role === 'restaurant') {
    $stmt = $db->prepare("SELECT restaurant_id FROM RestaurantProfiles WHERE user_id = :user_id");
    $stmt->bindValue(':user_id', $user_id, SQLITE3_INTEGER);
    $result = $stmt->execute();
    
    if ($row = $result->fetchArray(SQLITE3_ASSOC)) {
        $profile_id = $row['restaurant_id'];
        
        $stmt = $db->prepare("SELECT c.conversation_id, f.user_id as other_user_id 
                            FROM Conversations c
                            JOIN FreelancerProfiles f ON c.freelancer_id = f.profile_id
                            WHERE c.conversation_id = :conversation_id AND c.restaurant_id = :profile_id");
        $stmt->bindValue(':conversation_id', $conversation_id, SQLITE3_INTEGER);
        $stmt->bindValue(':profile_id', $profile_id, SQLITE3_INTEGER);
        $result = $stmt->execute();
        
        if ($row = $result->fetchArray(SQLITE3_ASSOC)) {
            $valid_conversation = true;
            $other_user_id = $row['other_user_id'];
        }
    }
}

// Se o usuário não tiver acesso à conversa, retornar erro
if (!$valid_conversation || !$other_user_id) {
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Acesso negado a esta conversa']);
    exit();
}

// Verificar se a tabela TypingStatus existe
try {
    $db->exec("CREATE TABLE IF NOT EXISTS TypingStatus (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                conversation_id INTEGER NOT NULL,
                user_id INTEGER NOT NULL,
                is_typing INTEGER DEFAULT 0,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (conversation_id) REFERENCES Conversations(conversation_id) ON DELETE CASCADE,
                FOREIGN KEY (user_id) REFERENCES Users(user_id) ON DELETE CASCADE,
                UNIQUE(conversation_id, user_id)
            )");
} catch (Exception $e) {
    // Ignorar erro se a tabela já existir
}

// Verificar status de digitação do outro usuário
$is_typing = false;
$timestamp = null;

try {
    $stmt = $db->prepare("SELECT is_typing, updated_at FROM TypingStatus 
                        WHERE conversation_id = :conversation_id AND user_id = :other_user_id");
    $stmt->bindValue(':conversation_id', $conversation_id, SQLITE3_INTEGER);
    $stmt->bindValue(':other_user_id', $other_user_id, SQLITE3_INTEGER);
    $result = $stmt->execute();
    
    if ($row = $result->fetchArray(SQLITE3_ASSOC)) {
        $is_typing = (bool)$row['is_typing'];
        $timestamp = $row['updated_at'];
        
        // Verificar se o status de digitação não está expirado (mais de 5 segundos)
        if ($is_typing && $timestamp) {
            $current_time = time();
            $updated_time = strtotime($timestamp);
            
            if ($current_time - $updated_time > 5) {
                $is_typing = false;
                
                // Atualizar o status para não estar mais digitando
                $stmt = $db->prepare("UPDATE TypingStatus SET is_typing = 0 
                                    WHERE conversation_id = :conversation_id AND user_id = :other_user_id");
                $stmt->bindValue(':conversation_id', $conversation_id, SQLITE3_INTEGER);
                $stmt->bindValue(':other_user_id', $other_user_id, SQLITE3_INTEGER);
                $stmt->execute();
            }
        }
    }
} catch (Exception $e) {
    // Em caso de erro, assumir que não está digitando
    $is_typing = false;
}

// Fechar a conexão com o banco de dados
$db = null;

// Retornar o status de digitação em formato JSON
header('Content-Type: application/json');
echo json_encode(['success' => true, 'is_typing' => $is_typing]);
exit();
?>