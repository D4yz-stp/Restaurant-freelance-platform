<?php
// Iniciar sessão
session_start();

// Verificar se o usuário está logado
if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_role'])) {
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Usuário não autenticado']);
    exit();
}

$user_id = $_SESSION['user_id'];
$user_role = $_SESSION['user_role'];

$databasePath = '../../database/TesteOlga.db';
if (!file_exists($databasePath)) {
    die("O arquivo de banco de dados não existe no caminho especificado: $databasePath");
}

if (!is_readable($databasePath)) {
    die("O arquivo de banco de dados não é legível. Verifique as permissões.");
}


// Conexão com o banco de dados
try {
    $db = new SQLite3($databasePath);
    $db->busyTimeout(5000);
    $db->exec('PRAGMA foreign_keys = ON;');

    $user_id = $_SESSION['user_id'];
    $user_role = $_SESSION['user_role'];

    // Obter perfil do usuário baseado no papel
    $profile_id = null;
    $conversations = [];

    // Continue com o resto do seu código...

} catch (Exception $e) {
    die("Erro ao conectar ao banco de dados: " . $e->getMessage());
}


$profile_id = null;
$conversations = [];

if ($user_role === 'freelancer') {
    $stmt = $db->prepare("SELECT profile_id FROM FreelancerProfiles WHERE user_id = :user_id");
    $stmt->bindValue(':user_id', $user_id, SQLITE3_INTEGER);
    $result = $stmt->execute();
    
    if ($row = $result->fetchArray(SQLITE3_ASSOC)) {
        $profile_id = $row['profile_id'];
        
        $stmt = $db->prepare("SELECT c.conversation_id, r.restaurant_name as name, u.profile_image_url, 
                            (SELECT COUNT(*) FROM Messages WHERE conversation_id = c.conversation_id 
                                AND sender_id != :user_id AND is_read = 0) as unread_count,
                            (SELECT message_text FROM Messages WHERE conversation_id = c.conversation_id 
                                ORDER BY created_at DESC LIMIT 1) as last_message,
                            (SELECT created_at FROM Messages WHERE conversation_id = c.conversation_id 
                                ORDER BY created_at DESC LIMIT 1) as last_message_time
                            FROM Conversations c
                            JOIN RestaurantProfiles r ON c.restaurant_id = r.restaurant_id
                            JOIN Users u ON r.user_id = u.user_id
                            WHERE c.freelancer_id = :profile_id
                            ORDER BY last_message_time DESC");
        $stmt->bindValue(':user_id', $user_id, SQLITE3_INTEGER);
        $stmt->bindValue(':profile_id', $profile_id, SQLITE3_INTEGER);
    }
} else if ($user_role === 'restaurant') {
    $stmt = $db->prepare("SELECT restaurant_id FROM RestaurantProfiles WHERE user_id = :user_id");
    $stmt->bindValue(':user_id', $user_id, SQLITE3_INTEGER);
    $result = $stmt->execute();
    
    if ($row = $result->fetchArray(SQLITE3_ASSOC)) {
        $profile_id = $row['restaurant_id'];
        
        $stmt = $db->prepare("SELECT c.conversation_id, 
                            (u.first_name || ' ' || u.last_name) as name, 
                            u.profile_image_url, 
                            (SELECT COUNT(*) FROM Messages WHERE conversation_id = c.conversation_id 
                                AND sender_id != :user_id AND is_read = 0) as unread_count,
                            (SELECT message_text FROM Messages WHERE conversation_id = c.conversation_id 
                                ORDER BY created_at DESC LIMIT 1) as last_message,
                            (SELECT created_at FROM Messages WHERE conversation_id = c.conversation_id 
                                ORDER BY created_at DESC LIMIT 1) as last_message_time
                            FROM Conversations c
                            JOIN FreelancerProfiles f ON c.freelancer_id = f.profile_id
                            JOIN Users u ON f.user_id = u.user_id
                            WHERE c.restaurant_id = :profile_id
                            ORDER BY last_message_time DESC");
        $stmt->bindValue(':user_id', $user_id, SQLITE3_INTEGER);
        $stmt->bindValue(':profile_id', $profile_id, SQLITE3_INTEGER);
    }
}

if (isset($stmt)) {
    $result = $stmt->execute();
    while ($row = $result->fetchArray(SQLITE3_ASSOC)) {
        $conversations[] = $row;
    }
}

// Fechar a conexão com o banco de dados
$db = null;

// Retornar as conversas em formato JSON
header('Content-Type: application/json');
echo json_encode(['success' => true, 'conversations' => $conversations]);
exit();
?>