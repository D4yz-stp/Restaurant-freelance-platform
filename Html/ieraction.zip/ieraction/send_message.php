<?php
// Iniciar sessão
session_start();

// Verificar se o usuário está logado
if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_role'])) {
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Usuário não autenticado']);
    exit();
}

// Verificar se os parâmetros necessários foram fornecidos
if (!isset($_POST['conversation_id']) || !isset($_POST['message'])) {
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Parâmetros insuficientes']);
    exit();
}

$conversation_id = (int)$_POST['conversation_id'];
$message = trim($_POST['message']);
$user_id = $_SESSION['user_id'];
$user_role = $_SESSION['user_role'];

// Verificar se a mensagem não está vazia
if (empty($message)) {
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Mensagem vazia']);
    exit();
}

$databasePath = '../../database/TesteOlga.db';
if (!file_exists($databasePath)) {
    die("O arquivo de banco de dados não existe no caminho especificado: $databasePath");
}

if (!is_readable($databasePath)) {
    die("O arquivo de banco de dados não é legível. Verifique as permissões.");
}


// Conexão com o banco de dados
try {
    $db = new SQLite3($databasePath);
    $db->busyTimeout(5000);
    $db->exec('PRAGMA foreign_keys = ON;');

    $user_id = $_SESSION['user_id'];
    $user_role = $_SESSION['user_role'];

    // Obter perfil do usuário baseado no papel
    $profile_id = null;
    $conversations = [];

    // Continue com o resto do seu código...

} catch (Exception $e) {
    die("Erro ao conectar ao banco de dados: " . $e->getMessage());
}


// Verificar se o usuário tem acesso à conversa
$valid_conversation = false;
$profile_id = null;

if ($user_role === 'freelancer') {
    $stmt = $db->prepare("SELECT f.profile_id FROM FreelancerProfiles f WHERE f.user_id = :user_id");
    $stmt->bindValue(':user_id', $user_id, SQLITE3_INTEGER);
    $result = $stmt->execute();
    
    if ($row = $result->fetchArray(SQLITE3_ASSOC)) {
        $profile_id = $row['profile_id'];
        
        $stmt = $db->prepare("SELECT conversation_id FROM Conversations 
                            WHERE conversation_id = :conversation_id AND freelancer_id = :profile_id");
        $stmt->bindValue(':conversation_id', $conversation_id, SQLITE3_INTEGER);
        $stmt->bindValue(':profile_id', $profile_id, SQLITE3_INTEGER);
        $result = $stmt->execute();
        
        if ($result->fetchArray(SQLITE3_ASSOC)) {
            $valid_conversation = true;
        }
    }
} else if ($user_role === 'restaurant') {
    $stmt = $db->prepare("SELECT restaurant_id FROM RestaurantProfiles WHERE user_id = :user_id");
    $stmt->bindValue(':user_id', $user_id, SQLITE3_INTEGER);
    $result = $stmt->execute();
    
    if ($row = $result->fetchArray(SQLITE3_ASSOC)) {
        $profile_id = $row['restaurant_id'];
        
        $stmt = $db->prepare("SELECT conversation_id FROM Conversations 
                            WHERE conversation_id = :conversation_id AND restaurant_id = :profile_id");
        $stmt->bindValue(':conversation_id', $conversation_id, SQLITE3_INTEGER);
        $stmt->bindValue(':profile_id', $profile_id, SQLITE3_INTEGER);
        $result = $stmt->execute();
        
        if ($result->fetchArray(SQLITE3_ASSOC)) {
            $valid_conversation = true;
        }
    }
}

// Se o usuário não tiver acesso à conversa, retornar erro
if (!$valid_conversation) {
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Acesso negado a esta conversa']);
    exit();
}

// Inserir a nova mensagem
try {
    $stmt = $db->prepare("INSERT INTO Messages (conversation_id, sender_id, message_text) 
                        VALUES (:conversation_id, :sender_id, :message_text)");
    $stmt->bindValue(':conversation_id', $conversation_id, SQLITE3_INTEGER);
    $stmt->bindValue(':sender_id', $user_id, SQLITE3_INTEGER);
    $stmt->bindValue(':message_text', $message, SQLITE3_TEXT);
    $stmt->execute();
    
    $message_id = $db->lastInsertRowID();
    
    // Também atualizar o status de digitação para false
    // Verificar se a tabela TypingStatus existe
    try {
        $stmt = $db->prepare("UPDATE TypingStatus SET is_typing = 0 
                            WHERE conversation_id = :conversation_id AND user_id = :user_id");
        $stmt->bindValue(':conversation_id', $conversation_id, SQLITE3_INTEGER);
        $stmt->bindValue(':user_id', $user_id, SQLITE3_INTEGER);
        $stmt->execute();
    } catch (Exception $e) {
        // Ignorar erro se a tabela não existir ou o registro não existir
    }
    
    header('Content-Type: application/json');
    echo json_encode(['success' => true, 'message_id' => $message_id]);
} catch (Exception $e) {
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Erro ao enviar mensagem: ' . $e->getMessage()]);
}

// Fechar a conexão com o banco de dados
$db = null;
?>